class Config:
  SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root:maru003@localhost/it_step"
  SQLALCHEMY_ECHO = True